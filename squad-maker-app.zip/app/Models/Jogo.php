<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Jogo extends Model
{
    protected $table = 'tb_jogo';

    protected $primaryKey = 'id_jogo';

    public $timestamps = false;

    protected $fillable = [
        'steam_app_id',
        'nome',
        'capa',
        'dt_lancamento',
        'descricao',
        'jogadores_online',
        'jogadores_online_atualizado_em',
    ];

    protected $casts = [
        'dt_lancamento' => 'date',
        'jogadores_online' => 'integer',
        'jogadores_online_atualizado_em' => 'datetime',
    ];

    public function generos()
    {
        return $this->belongsToMany(
            Genero::class,
            'tb_jogo_genero',
            'id_jogo',
            'id_genero'
        );
    }

    public function modos()
    {
        return $this->belongsToMany(
            ModoJogo::class,
            'tb_jogo_modo',
            'id_jogo',
            'id_modo_jogo'
        );
    }

    public function usuarios()
    {
        return $this->belongsToMany(
            User::class,
            'tb_jogo_usuario',
            'id_jogo',
            'id_usuario'
        )->withPivot([
            'data_adicao',
            'nivel_proficiencia',
            'ordem_perfil',
        ]);
    }
}

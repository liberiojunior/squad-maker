@extends('layouts.app')
@push('styles')
    <link rel="stylesheet" href="{{ asset('css/auth.css') }}">
@endpush

@section('content')

    <main class="register-page">

        <div class="register-container">

            <img
                src="{{ asset('images/logo.png') }}"
                alt="Squad Maker"
                class="register-logo"
            >

            <div class="register-card">

                <h1>Crie sua conta</h1>

                <p class="register-subtitle">
                    Preencha os dados para criar seu acesso.
                </p>

                <form
                    method="POST"
                    action="{{ route('cadastro.store') }}"
                    class="register-form"
                    autocomplete="off"
                >
                    @csrf

                    <div>
                        <label for="nickname" class="form-label">
                            Nome que será mostrado
                        </label>

                        <input
                            type="text"
                            id="nickname"
                            name="nickname"
                            class="form-control"
                            maxlength="80"
                            value="{{ old('nickname') }}"
                            required
                        >

                        @error('nickname')
                        <span class="register-error">
                            {{ $message }}
                        </span>
                        @enderror
                    </div>

                    <div>
                        <label for="email" class="form-label">
                            E-mail
                        </label>

                        <input
                            type="email"
                            id="email"
                            name="email"
                            class="form-control"
                            value="{{ old('email') }}"
                            autocomplete="off"
                            required
                        >

                        @error('email')
                        <span class="register-error">
                            {{ $message }}
                        </span>
                        @enderror
                    </div>

                    <div>
                        <label for="cpf" class="form-label">
                            CPF
                        </label>

                        <input
                            type="text"
                            id="cpf"
                            name="cpf"
                            class="form-control"
                            maxlength="14"
                            inputmode="numeric"
                            autocomplete="off"
                            placeholder="000.000.000-00"
                            required
                        >

                        @error('cpf')
                        <span class="register-error">
                            {{ $message }}
                        </span>
                        @enderror
                    </div>

                    <div>
                        <label for="password" class="form-label">
                            Senha
                        </label>

                        <input
                            type="password"
                            id="password"
                            name="password"
                            class="form-control"
                            autocomplete="new-password"
                            required
                        >

                        @error('password')
                        <span class="register-error">
                            {{ $message }}
                        </span>
                        @enderror
                    </div>

                    <div>
                        <label for="password_confirmation" class="form-label">
                            Confirmar senha
                        </label>

                        <input
                            type="password"
                            id="password_confirmation"
                            name="password_confirmation"
                            class="form-control"
                            autocomplete="new-password"
                            required
                        >
                    </div>

                    <div class="form-check register-age">

                        <input
                            type="checkbox"
                            id="termos"
                            name="termos"
                            value="1"
                            class="form-check-input"
                            {{ old('termos') ? 'checked' : '' }}
                            required
                        >

                        <label
                            for="termos"
                            class="form-check-label"
                        >
                            Li e aceito os
                            <a
                                href="{{ route('termos') }}"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                Termos de Uso e Política de Privacidade
                            </a>.
                        </label>

                    </div>

                    @error('termos')
                    <span class="register-error">
                        {{ $message }}
                    </span>
                    @enderror

                    <button
                        type="submit"
                        class="btn register-button"
                    >
                        Criar conta
                    </button>

                </form>

                <a
                    href="{{ route('login') }}"
                    class="register-login-link"
                >
                    Já tenho uma conta
                </a>

            </div>

        </div>

    </main>

    <script src="{{ asset('js/cadastro.js') }}"></script>

@endsection

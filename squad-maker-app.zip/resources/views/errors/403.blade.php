<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Acesso negado - Squad Maker</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>

<body class="error-page">

<div class="error-card">

    <h1>403</h1>

    <h2>Acesso negado</h2>

    <p>
        Você não possui permissão para acessar esta área.
    </p>
</div>

</body>
</html>

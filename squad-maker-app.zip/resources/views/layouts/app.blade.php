<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Squad Maker</title>

    @if (request()->routeIs('cadastro.jogos*'))
        <link rel="preload" as="image" href="{{ asset('images/fundo2.jpg') }}">
    @else
        <link rel="preload" as="image" href="{{ asset('images/fundo.jpg') }}">
    @endif

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    >

    <link
        rel="stylesheet"
        href="{{ asset('css/app.css') }}"
    >

    @stack('styles')
</head>

<body>

<nav class="navbar navbar-expand-md navbar-dark squad-navbar">
    <div class="container-fluid position-relative px-3">

        <a
            class="navbar-brand"
            href="{{ route('login') }}"
        >
            <img
                src="{{ asset('images/icone.png') }}"
                alt="Squad Maker"
                class="navbar-logo"
            >
        </a>

        <button
            class="navbar-toggler ms-auto"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#mainNavbar"
            aria-controls="mainNavbar"
            aria-expanded="false"
            aria-label="Abrir navegação"
        >
            <span class="navbar-toggler-icon"></span>
        </button>

        <div
            class="collapse navbar-collapse justify-content-center"
            id="mainNavbar"
        >
            <ul class="navbar-nav text-center">
                <li class="nav-item">
                    <a
                        class="nav-link"
                        href="{{ route('sobre-nos') }}"
                    >
                        Sobre Nós
                    </a>
                </li>

                <li class="nav-item">
                    <a
                        class="nav-link"
                        href="{{ route('equipe') }}"
                    >
                        A Equipe
                    </a>
                </li>

                <li class="nav-item">
                    <a
                        class="nav-link"
                        href="{{ route('contato') }}"
                    >
                        Contato
                    </a>
                </li>
            </ul>
        </div>

    </div>
</nav>

@yield('content')

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
></script>

<script src="{{ asset('js/app.js') }}"></script>

</body>
</html>

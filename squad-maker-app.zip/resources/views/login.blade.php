@extends('layouts.app')
@push('styles')
    <link rel="stylesheet" href="{{ asset('css/auth.css') }}">
@endpush

@section('content')

    <main class="login-page">

        <div class="login-container">

            <img
                src="{{ asset('images/logo.png') }}"
                alt="Squad Maker"
                class="login-logo"
            >

            <p class="login-subtitle">
                Encontre quem joga do seu jeito!
            </p>

            @if ($errors->any())

                <div class="alert alert-danger">

                    @foreach ($errors->all() as $error)
                        <div>{{ $error }}</div>
                    @endforeach

                </div>

            @endif


            <form
                method="POST"
                action="{{ route('login.submit') }}"
                class="login-form"
            >
                @csrf

                <input
                    type="email"
                    name="email"
                    class="form-control"
                    placeholder="email"
                    value="{{ old('email') }}"
                >

                <input
                    type="password"
                    name="password"
                    class="form-control"
                    placeholder="senha"
                >

                @error('email')
                <span class="login-error">
                    {{ $message }}
                </span>
                @enderror

                @error('password')
                <span class="login-error">
                    {{ $message }}
                </span>
                @enderror

                <a
                    href="{{ route('password.request') }}"
                    class="forgot-password-link"
                >
                    Esqueci minha senha
                </a>

                <button
                    type="submit"
                    class="btn login-button"
                >
                    Iniciar sessão
                </button>

            </form>

            <a
                href="{{ route('google.redirect') }}"
                class="google-link"
            >
                Entrar com Google
            </a>

            <a href="{{ route('cadastro') }}" class="register-link">
                Ou cadastre-se gratuitamente
            </a>

        </div>

    </main>

@endsection
